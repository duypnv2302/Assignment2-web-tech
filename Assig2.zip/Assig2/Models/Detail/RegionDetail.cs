﻿namespace Assig2.Models
{
    public class RegionDetail
    {
        public int RegionId { get; set; } = 0;
        public string RegionName { get; set; } = "All Regions and Countries";
        public string ImageUrl { get; set; } = "";
        public int CountryCount { get; set; } = 0;
    }
}
