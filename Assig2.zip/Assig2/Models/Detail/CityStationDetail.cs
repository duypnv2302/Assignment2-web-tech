﻿namespace Assig2.Models
{
    public class CityStationDetail
    {
        public string StationType { get; set; } = string.Empty;
        public int StationNumber { get; set; }
    }
}
